# Animations
## Arioun Website — Skill 03

---

## CSS Keyframes

```css
/* ── Fade Up ─────────────────────────────────────── */
/* Use for hero stagger on page load */
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(24px); }
  to   { opacity: 1; transform: translateY(0); }
}
.animate-fade-up { animation: fadeUp 0.7s ease forwards; opacity: 0; }
.delay-1 { animation-delay: 0.10s; }
.delay-2 { animation-delay: 0.22s; }
.delay-3 { animation-delay: 0.34s; }
.delay-4 { animation-delay: 0.46s; }
.delay-5 { animation-delay: 0.58s; }

/* ── Scroll Reveal ───────────────────────────────── */
/* Add .reveal to any element — JS triggers .visible */
.reveal {
  opacity: 0;
  transform: translateY(20px);
  transition: opacity 0.6s ease, transform 0.6s ease;
}
.reveal.visible {
  opacity: 1;
  transform: translateY(0);
}

/* ── Pulse ───────────────────────────────────────── */
/* Live indicator dot in hero eyebrow */
@keyframes pulse {
  0%,100% { opacity: 1; transform: scale(1); }
  50%      { opacity: 0.4; transform: scale(0.7); }
}
.pulse { animation: pulse 2s infinite; }

/* ── Marquee ─────────────────────────────────────── */
@keyframes marquee {
  from { transform: translateX(0); }
  to   { transform: translateX(-50%); }
}

/* ── Blink ───────────────────────────────────────── */
@keyframes blink {
  0%,100% { opacity: 1; }
  50%      { opacity: 0.3; }
}
.blink { animation: blink 1.8s infinite; }

/* ── Shimmer (skeleton loader) ───────────────────── */
@keyframes shimmer {
  0%   { background-position: -200% 0; }
  100% { background-position:  200% 0; }
}
.shimmer {
  background: linear-gradient(
    90deg,
    var(--bg-secondary) 25%,
    var(--bg-tertiary) 50%,
    var(--bg-secondary) 75%
  );
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
}
```

---

## JavaScript — Scroll Reveal

```javascript
// animations.js
(function() {
  'use strict';

  // Scroll reveal — Intersection Observer
  function initReveal() {
    var els = document.querySelectorAll('.reveal');
    if (!els.length) return;

    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target); // fire once only
        }
      });
    }, { threshold: 0.15 });

    els.forEach(function(el) { observer.observe(el); });
  }

  // Animated counter — fires when stat enters viewport
  function initCounters() {
    var counters = document.querySelectorAll('[data-count]');
    if (!counters.length) return;

    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (!entry.isIntersecting) return;
        var el = entry.target;
        var target = parseInt(el.getAttribute('data-count'), 10);
        var duration = 1500;
        var start = performance.now();

        function update(now) {
          var elapsed = now - start;
          var progress = Math.min(elapsed / duration, 1);
          // Ease out cubic
          var ease = 1 - Math.pow(1 - progress, 3);
          el.textContent = Math.round(ease * target);
          if (progress < 1) requestAnimationFrame(update);
        }
        requestAnimationFrame(update);
        observer.unobserve(el);
      });
    }, { threshold: 0.5 });

    counters.forEach(function(el) { observer.observe(el); });
  }

  document.addEventListener('DOMContentLoaded', function() {
    initReveal();
    initCounters();
  });
})();
```

---

## Animation Rules

- **Hero elements:** use `animate-fade-up` with stagger delays (`.delay-1` → `.delay-5`)
- **Section content:** wrap in `<div class="reveal">` — JS triggers `.visible` on scroll
- **Never** auto-play more than 3 animations simultaneously
- **Hover transitions:** always 200–250ms ease
- **Reveal transitions:** always 600ms ease
- **No** spinning loaders, bouncing elements, or excessive motion
- **Counters:** use `data-count="20"` attribute — JS animates from 0 to value
- **Performance:** always use `transform` and `opacity` only — never animate `height`, `width`, or `margin`
