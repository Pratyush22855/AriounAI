# Components
## Arioun Website — Skill 02

Every component is defined here with full CSS. Copy exactly. No deviations.

---

## Buttons

```css
.btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 0.85rem 2rem;
  border-radius: var(--radius-sm);     /* Sharp — not pill */
  font-family: var(--font-body);
  font-weight: 600;
  font-size: 0.88rem;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  cursor: pointer;
  border: none;
  text-decoration: none;
  transition: all 0.22s ease;
  white-space: nowrap;
  position: relative;
}

/* Primary — Emerald fill */
.btn-primary {
  background: var(--accent);
  color: #000;
  box-shadow: var(--shadow-btn);
}
.btn-primary:hover {
  background: var(--accent-bright);
  box-shadow: var(--shadow-btn-hover);
  transform: translateY(-2px);
}

/* Secondary — Ghost */
.btn-secondary {
  background: transparent;
  color: var(--text-primary);
  border: 1px solid rgba(255,255,255,0.15);
}
.btn-secondary:hover {
  border-color: var(--accent);
  color: var(--accent);
}

/* Dark — for use on accent/emerald backgrounds */
.btn-dark {
  background: #000;
  color: var(--accent);
}
.btn-dark:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
}

/* Sizes */
.btn-sm  { padding: 0.55rem 1.2rem;  font-size: 0.78rem; }
.btn-lg  { padding: 1.1rem  2.6rem;  font-size: 0.95rem; }
.btn-xl  { padding: 1.3rem  3.2rem;  font-size: 1.05rem; }
```

---

## Cards

```css
/* Base card */
.card {
  background: var(--bg-secondary);
  border: 1px solid var(--accent-border);
  border-radius: var(--radius-lg);
  padding: 2.5rem;
  transition: all 0.25s ease;
  position: relative;
  overflow: hidden;
}

/* Top accent line — visible on hover */
.card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2px;
  background: linear-gradient(90deg, transparent, var(--accent), transparent);
  opacity: 0;
  transition: opacity 0.3s;
}

.card:hover {
  background: var(--bg-tertiary);
  border-color: rgba(0,217,126,0.3);
  transform: translateY(-4px);
  box-shadow: var(--shadow-lg), var(--shadow-glow);
}
.card:hover::before { opacity: 1; }

/* Numbered card — for services */
.card-numbered .card-num {
  font-family: var(--font-display);
  font-size: 5rem;
  font-weight: 900;
  color: transparent;
  -webkit-text-stroke: 1px rgba(0,217,126,0.2);
  line-height: 1;
  margin-bottom: 1rem;
  display: block;
  user-select: none;
}

/* Highlight card — accent tinted */
.card-highlight {
  background: rgba(0,217,126,0.04);
  border-left: 2px solid var(--accent);
}

/* Stat card */
.card-stat .stat-val {
  font-family: var(--font-display);
  font-size: 3rem;
  font-weight: 900;
  color: var(--accent);
  display: block;
  line-height: 1;
  margin-bottom: 0.4rem;
}
.card-stat .stat-label {
  font-size: 0.82rem;
  color: var(--text-muted);
  font-weight: 500;
}
```

---

## Section Tag (eyebrow above every H2)

```css
.section-tag {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.16em;
  text-transform: uppercase;
  color: var(--accent);
  margin-bottom: 1.4rem;
}
.section-tag::before {
  content: '';
  width: 28px;
  height: 1px;
  background: var(--accent);
  flex-shrink: 0;
}
```

**Usage — every section must start with this:**
```html
<span class="section-tag">Category Label</span>
<h2 class="t-h2">Section Headline</h2>
```

---

## Hero Eyebrow Badge

```css
.eyebrow {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  background: rgba(0,217,126,0.08);
  border: 1px solid rgba(0,217,126,0.2);
  border-radius: 2px;
  padding: 0.45rem 1.1rem;
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--accent);
  margin-bottom: 2rem;
}
.eyebrow-dot {
  width: 6px;
  height: 6px;
  background: var(--accent);
  border-radius: 50%;
  animation: pulse 1.8s infinite;
}
```

---

## Navbar

```css
.navbar {
  position: fixed;
  top: 0; left: 0; right: 0;
  z-index: 1000;
  height: 70px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 5%;
  background: rgba(10,12,15,0.92);
  backdrop-filter: blur(24px);
  -webkit-backdrop-filter: blur(24px);
  border-bottom: 1px solid var(--accent-border);
  transition: box-shadow 0.3s;
}
.navbar.scrolled {
  box-shadow: 0 4px 40px rgba(0,0,0,0.5);
}

/* Logo */
.logo {
  font-family: var(--font-display);
  font-weight: 900;
  font-size: 1.5rem;
  display: flex;
  align-items: center;
  gap: 10px;
  color: var(--text-primary);
  text-decoration: none;
}
.logo-mark {
  width: 32px; height: 32px;
  background: var(--accent);
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-body);
  font-weight: 800;
  font-size: 0.9rem;
  color: #000;
  box-shadow: 0 0 16px rgba(0,217,126,0.4);
  flex-shrink: 0;
}

/* Nav links */
.nav-links {
  display: flex;
  gap: 2.5rem;
  list-style: none;
}
.nav-links a {
  font-family: var(--font-body);
  font-size: 0.88rem;
  font-weight: 500;
  color: var(--text-muted);
  text-decoration: none;
  transition: color 0.2s;
  letter-spacing: 0.03em;
}
.nav-links a:hover,
.nav-links a.active { color: var(--text-primary); }

/* Hamburger */
.hamburger {
  display: none;
  flex-direction: column;
  gap: 5px;
  background: none;
  border: none;
  cursor: pointer;
  padding: 5px;
}
.hamburger span {
  display: block;
  width: 24px; height: 2px;
  background: var(--text-primary);
  border-radius: 2px;
  transition: all 0.3s;
}

/* Mobile nav overlay */
.mobile-nav {
  display: none;
  position: fixed;
  inset: 0; top: 70px;
  z-index: 999;
  background: rgba(10,12,15,0.98);
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2.5rem;
}
.mobile-nav.open { display: flex; }
.mobile-nav a {
  font-family: var(--font-display);
  font-size: 2rem;
  font-weight: 900;
  color: var(--text-primary);
  text-decoration: none;
  transition: color 0.2s;
}
.mobile-nav a:hover { color: var(--accent); }
```

---

## Hero Section

```css
.hero {
  min-height: 100vh;
  display: flex;
  align-items: center;
  padding-top: 130px;
  padding-bottom: 80px;
  position: relative;
  overflow: hidden;
}

/* Geometric grid background */
.hero-grid {
  position: absolute; inset: 0;
  pointer-events: none;
  background-image:
    linear-gradient(rgba(0,217,126,0.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,217,126,0.04) 1px, transparent 1px);
  background-size: 80px 80px;
  mask-image: radial-gradient(ellipse 90% 90% at 60% 40%, black 30%, transparent 80%);
}

/* Radial glow */
.hero-glow {
  position: absolute;
  top: 0; left: 0; right: 0; height: 60%;
  background: radial-gradient(ellipse 70% 50% at 50% 0%, rgba(0,217,126,0.07), transparent);
  pointer-events: none;
}

/* Decorative orbital ring */
.hero-orb {
  position: absolute;
  right: -8%; top: 5%;
  width: 700px; height: 700px;
  border-radius: 50%;
  border: 1px solid rgba(0,217,126,0.06);
  pointer-events: none;
}
.hero-orb::after {
  content: '';
  position: absolute;
  inset: 80px;
  border-radius: 50%;
  border: 1px solid rgba(0,217,126,0.04);
}
.hero-orb::before {
  content: '';
  position: absolute;
  inset: 160px;
  border-radius: 50%;
  border: 1px solid rgba(0,217,126,0.025);
}

/* Hero stats row */
.hero-stats {
  display: flex;
  gap: 3.5rem;
  flex-wrap: wrap;
  padding-top: 3rem;
  border-top: 1px solid rgba(255,255,255,0.07);
  margin-top: 3.5rem;
}
.hero-stat-val {
  font-family: var(--font-display);
  font-size: 2.4rem;
  font-weight: 900;
  color: var(--text-primary);
  display: block;
  line-height: 1;
  margin-bottom: 0.3rem;
}
.hero-stat-val em {
  font-style: normal;
  color: var(--accent);
}
.hero-stat-label {
  font-size: 0.75rem;
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.1em;
  font-weight: 600;
}
```

---

## Marquee / Ticker Strip

```css
.marquee-wrap {
  border-top: 1px solid var(--accent-border);
  border-bottom: 1px solid var(--accent-border);
  background: var(--bg-secondary);
  padding: 1rem 0;
  overflow: hidden;
}
.marquee-track {
  display: flex;
  gap: 4rem;
  white-space: nowrap;
  animation: marquee 26s linear infinite;
  width: max-content;
}
.marquee-item {
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: var(--text-muted);
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-shrink: 0;
}
.marquee-item::after {
  content: '✦';
  color: var(--accent);
  font-size: 0.5rem;
}
```

---

## Divider Rule

```css
.rule {
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--accent-border), transparent);
  border: none;
  margin: 0;
}
```

---

## CTA Band (end of every page)

```css
.cta-band {
  background: var(--accent);
  padding: 80px 5%;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.cta-band::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    -45deg,
    transparent, transparent 20px,
    rgba(0,0,0,0.04) 20px, rgba(0,0,0,0.04) 40px
  );
}
.cta-band > * { position: relative; z-index: 2; }
.cta-band h2 {
  font-family: var(--font-display);
  color: #000;
  font-size: clamp(2rem, 5vw, 4rem);
  font-weight: 900;
  margin-bottom: 1rem;
}
.cta-band p {
  color: rgba(0,0,0,0.65);
  font-size: 1.1rem;
  margin-bottom: 2rem;
  font-weight: 300;
}
```

---

## Testimonial Card

```css
.testimonial-card {
  background: var(--bg-secondary);
  border: 1px solid var(--accent-border);
  border-radius: var(--radius-lg);
  padding: 2.2rem;
  position: relative;
}
.testimonial-card::before {
  content: '"';
  position: absolute;
  top: 1rem; right: 1.5rem;
  font-family: var(--font-display);
  font-size: 5rem;
  font-weight: 900;
  color: rgba(0,217,126,0.08);
  line-height: 1;
}
.testimonial-stars {
  color: var(--accent);
  letter-spacing: 3px;
  font-size: 0.85rem;
  margin-bottom: 1rem;
}
.testimonial-body {
  font-size: 0.95rem;
  line-height: 1.8;
  font-style: italic;
  opacity: 0.9;
  margin-bottom: 1.5rem;
  color: var(--text-primary);
}
.testimonial-author {
  display: flex;
  align-items: center;
  gap: 12px;
}
.testimonial-avatar {
  width: 44px; height: 44px;
  border-radius: var(--radius-sm);
  background: linear-gradient(135deg, var(--accent-dim), var(--accent));
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 0.82rem;
  color: #000;
  flex-shrink: 0;
}
```

---

## Contact Info Block

```css
.info-block {
  display: flex;
  gap: 1.2rem;
  align-items: flex-start;
  padding: 1.5rem 2rem;
  background: var(--bg-secondary);
  border: 1px solid var(--accent-border);
  border-radius: var(--radius-lg);
  margin-bottom: 1rem;
  transition: border-color 0.2s;
}
.info-block:hover { border-color: rgba(0,217,126,0.3); }
.info-icon {
  width: 46px; height: 46px;
  background: rgba(0,217,126,0.1);
  border: 1px solid rgba(0,217,126,0.2);
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.1rem;
  flex-shrink: 0;
}
.info-label {
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--text-muted);
  margin-bottom: 0.3rem;
}
.info-value {
  font-weight: 600;
  font-size: 0.95rem;
  color: var(--text-primary);
}
.info-value a {
  color: inherit;
  text-decoration: none;
  transition: color 0.2s;
}
.info-value a:hover { color: var(--accent); }
```

---

## Industry Pill

```css
.industry-pill {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--bg-secondary);
  border: 1px solid var(--accent-border);
  border-radius: 2px;
  padding: 0.6rem 1.3rem;
  font-family: var(--font-body);
  font-size: 0.85rem;
  font-weight: 500;
  transition: all 0.2s;
  cursor: default;
}
.industry-pill:hover {
  border-color: var(--accent);
  color: var(--accent);
  background: rgba(0,217,126,0.06);
}
```

---

## Feature Visual Box

```css
.feature-visual {
  background: var(--bg-secondary);
  border: 1px solid var(--accent-border);
  border-radius: var(--radius-lg);
  min-height: 320px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
}
.feature-visual::after {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 70% 70% at 50% 50%, rgba(0,217,126,0.04), transparent);
  pointer-events: none;
}
.feature-visual-inner {
  text-align: center;
  position: relative;
  z-index: 2;
}
.feature-visual-icon {
  font-size: 4.5rem;
  display: block;
  margin-bottom: 1rem;
}
.feature-visual-caption {
  font-size: 0.82rem;
  color: var(--text-muted);
  max-width: 200px;
  line-height: 1.6;
}
```

---

## Process Step

```css
.process-step {
  padding: 2.5rem;
  border-right: 1px solid var(--accent-border);
  border-bottom: 1px solid var(--accent-border);
  transition: background 0.22s;
}
.process-step:hover { background: var(--bg-tertiary); }
.process-step-num {
  font-family: var(--font-display);
  font-size: 5rem;
  font-weight: 900;
  color: transparent;
  -webkit-text-stroke: 1px rgba(0,217,126,0.18);
  line-height: 1;
  margin-bottom: 0.8rem;
  display: block;
  user-select: none;
}
.process-step-day {
  display: inline-block;
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--accent);
  background: rgba(0,217,126,0.08);
  border-radius: 2px;
  padding: 2px 10px;
  margin-bottom: 0.8rem;
}
.process-step h3 {
  font-family: var(--font-display);
  font-size: 1.1rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
  color: var(--text-primary);
}
.process-step p {
  font-size: 0.88rem;
  color: var(--text-muted);
  line-height: 1.7;
}
```

---

## Footer

```css
footer {
  background: var(--bg-secondary);
  border-top: 1px solid var(--accent-border);
  padding: 3.5rem 5%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 1.5rem;
}
.footer-nav {
  display: flex;
  gap: 2rem;
  flex-wrap: wrap;
}
.footer-nav a {
  font-size: 0.83rem;
  color: var(--text-muted);
  text-decoration: none;
  transition: color 0.2s;
}
.footer-nav a:hover { color: var(--accent); }
footer p {
  font-size: 0.82rem;
  color: var(--text-muted);
}
```
