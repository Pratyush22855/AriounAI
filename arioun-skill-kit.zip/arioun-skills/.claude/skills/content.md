# Content
## Arioun Website — Skill 05

All company copy, data, and text for the website. Use exactly as written.

---

## Company Info

```
Name:      Arioun
Tagline:   AI Infrastructure for Local Business
Phone:     (928) 208-8239
Email:     main@arioun.com
Website:   arioun.com
Demo link: https://calendly.com/main-arioun/45min
Location:  Arizona, USA
AI Agent:  Peter (Voiceflow)
```

---

## Hero Section

**Eyebrow:** AI Systems Now Live for Local Businesses

**Headline:**
```
Your business,
fully automated.
Done for you.
```
("fully automated." = italic, emerald color)

**Subtext:**
We build and manage complete AI infrastructure for local businesses — call agents, chatbots, review systems, social automation, and customer reactivation. You never touch a single tool.

**CTAs:** Book a Free Demo →  |  See What We Build

**Stats:**
| Value | Label |
|---|---|
| 24/7 | AI Always On |
| 20d | Days to Live |
| 5+ | AI Systems |
| 0 | Tools You Touch |

---

## Marquee Items (duplicate twice in DOM for seamless loop)

AI Call Agent · Reputation Manager · Social Automation · Customer Reactivation · Website + AI Chat · Done For You · Live in 20 Days · No Software Needed · Monthly Management

---

## Services Section

**Tag:** What We Build
**Headline:** Five AI systems. Zero effort from you.
**Subtext:** We install the full infrastructure and manage it every month. The client never touches a tool.

### Service Cards

| # | Title | Description |
|---|---|---|
| 01 | AI Call Agent | 24/7 AI receptionist answering every call, handling FAQs, and booking appointments directly to your calendar. |
| 02 | Website + AI Chat | A professionally built website with an embedded AI chat widget that captures leads and books appointments around the clock. |
| 03 | Reputation Manager | AI replies to every Google review within the hour. Automated post-visit SMS drives 5-star reviews consistently. |
| 04 | Social Media AI | Weekly AI-generated content ideas, auto-scheduled posts, and one-click SMS promo blasts to your customer list. |
| 05 | AI Reactivation | Identifies lapsed customers and reaches out with personalised SMS automatically. 10–15% reactivation rate. |
| ∞ | Monthly Management | We don't install and disappear. Every system is checked, refined, and optimised every single month. |

---

## Why Arioun Section

**Tag:** Why Arioun
**Headline:** We don't sell software. We *install outcomes.*

| Icon | Title | Body |
|---|---|---|
| 🤝 | Completely Done For You | Every tool built, tested, and managed by us. You never log in, configure, or touch anything. |
| ⚡ | Live in 20 Days | Most agencies take 6–8 weeks. We have clients fully live in 20 business days — every time. |
| 🎯 | Built for Local Business | Not enterprise software. Every system is configured for barbershops, clinics, gyms, and local SMBs. |
| 📈 | Improving Every Month | Monthly reviews, prompt refinements, and performance reports so your AI keeps compounding. |

---

## Industries Section

**Tag:** Industries We Serve
**Headline:** Built for the businesses that keep communities running.
**Subtext:** If you serve local customers and want AI without the complexity — we're your team.

**Pills:** ✂️ Barbershops · 💇 Hair Salons · 🦷 Dental Clinics · 🏋️ Gyms & Fitness · 🏠 Real Estate · ⚖️ Law Firms · 🍽️ Restaurants · 💅 Beauty Salons · 🏥 Medical Clinics · 🔧 Trade Services · 🏡 Property Management · + More

---

## Testimonials Section

**Tag:** Client Results
**Headline:** Real businesses. Real AI. Real results.

### Testimonial 1
> "We used to miss calls every weekend. Now the AI handles everything — bookings, FAQs, after-hours. Haven't missed a booking in two months."
— **Marcus R.**, Owner, Premier Barbershop ★★★★★

### Testimonial 2
> "The reactivation campaign brought back 18 patients in the first month. One crown appointment paid for the entire service for a year."
— **Dr. Sarah K.**, Principal Dentist, Smile Studio ★★★★★

### Testimonial 3
> "Google rating went from 3.8 to 4.7 in 90 days. Arioun set it up, I never touched a thing. The difference has been transformational."
— **Jessica L.**, Director, Luxe Wellness Spa ★★★★★

---

## Final CTA Band

**Headline:** Your competitors will have AI. Be the one who had it first.
**Subtext:** Book a free 30-minute demo. No commitment. No jargon. Just a live walkthrough.
**CTA:** Schedule Your Free Demo →

---

## Services Page (Detailed)

**Tag:** Our Services
**Headline:** Five AI systems. One operational partner.
**Subtext:** Everything built, tested, and managed for you. No software to learn. No dashboards to check.

### Service 1 — AI Call Agent
A 24/7 AI phone receptionist that answers every single call, handles FAQs in your brand voice, and books appointments directly into your calendar in real time. It sounds natural and never takes a day off.

**Benefits:**
- Answers calls 24/7 — nights, weekends, holidays
- Books appointments directly to your calendar in real time
- Handles FAQs in your brand voice
- Replaces a part-time receptionist saving $1,500–$2,500/mo
- Escalates complex calls to a human when needed

**Visual caption:** Every call answered. Every booking captured.

### Service 2 — Website + AI Chat
A professionally built, mobile-responsive website with an embedded AI chat widget that answers questions and books appointments 24/7. We build the entire site — you just approve the design.

**Benefits:**
- Custom website built and published by us
- AI chat widget handles questions and bookings around the clock
- Mobile responsive and SEO optimised
- Replaces a web developer and a live chat agent

**Visual caption:** A website that works while you sleep.

### Service 3 — Reputation Manager
Automated Google review monitoring with AI-generated professional replies within the hour. Post-visit SMS nudges happy customers to leave 5-star reviews. Your rating climbs on autopilot.

**Benefits:**
- AI replies to every Google review automatically
- Post-visit SMS requests reviews from happy customers
- Consistent brand tone across all responses
- Ratings improve without any manual effort

**Visual caption:** 3.8 → 4.7 stars in 90 days. Automatically.

### Service 4 — Social Media Automation
Weekly AI-generated post ideas emailed for one-click approval, then auto-scheduled to Instagram and Facebook. Plus SMS promo blasts to your customer list on slow days.

**Benefits:**
- Weekly content ideas — one-click approval
- Auto-posts to Instagram and Facebook
- SMS promo blasts to your full customer list
- Consistent presence with zero ongoing effort

**Visual caption:** Stay visible without the time cost.

### Service 5 — AI Follow-Up & Reactivation
The service nobody else does at the SMB level. We identify customers who haven't returned in 60+ days and reach out automatically via personalised SMS. 10–15% come back.

**Benefits:**
- Automatically identifies lapsed customers
- AI writes personalised, human-sounding SMS
- Sends booking link on positive replies
- 10–15% reactivation rate consistently
- Zero effort — fully automated end to end

**Visual caption:** 30+ re-bookings/month from customers you'd written off.

---

## How It Works Page

**Tag:** The Process
**Headline:** From demo call to live in 20 days.
**Subtext:** Six stages. Zero complexity on your end. We do the work — you approve, then go live.

| Step | Day | Title | Description |
|---|---|---|---|
| 01 | Day 1–3 | Demo Call | A focused 30-minute call. Live demo tailored to your industry. We recommend the right services. No pressure. |
| 02 | Day 2–5 | Proposal & Sign | One-page proposal. Sign digitally. Setup fee via Stripe. Everything clear and simple before anything is built. |
| 03 | Day 3–6 | Onboarding Call | 45 minutes. We collect your brand voice, services, FAQs, and calendar access. You send assets once. We never ask again. |
| 04 | Day 4–14 | Build Phase | Our technical team builds every service purchased. Call agent. Automations. Website. You don't touch a thing. |
| 05 | Day 12–17 | Testing & Approval | 20 test calls. 15 chat scenarios. All automations verified. You review everything and approve before go-live. |
| 06 | Day 17–20 | Go Live | Phone forwarded. Website live. Automations on. Your business is now running full AI infrastructure. |
| ∞ | Every Month | Monthly Management | System checks, prompt refinements, performance reporting, and a dedicated account manager. |

---

## About Page

**Tag:** About Arioun
**Headline:** We exist to give local business the *AI edge.*

**Tag:** Why We Started
**Headline:** The gap was too obvious to ignore.

**Body:**
In 2025, AI is everywhere. Every headline. Every conference. But walk into a barbershop, a dental clinic, a local gym — and nothing has changed. These business owners know AI exists. They just have nobody to install it.

Software companies sell licences and say good luck. Tech agencies build for enterprise. Nobody builds, installs, and manages complete AI systems for local businesses at a price that makes sense.

That gap is where Arioun was born.

**Mission:** To give every local business the AI infrastructure that enterprise companies have — installed and managed, without the complexity or cost.

**Vision:** A future where every independent business owner can focus entirely on their craft — while AI handles the operations.

**Stat Cards:**
| Value | Label |
|---|---|
| 20d | Average time from sign to live |
| 5+ | AI services per client install |
| 0 | Tools the client ever touches |
| ∞ | Monthly refinements |

**Tag:** Why AI Now
**Headline:** The window is open. For now.

| Title | Body |
|---|---|
| Missed Calls = Lost Revenue | The average local business misses 35% of inbound calls. Every one is a lost booking — often to a competitor who answered. |
| Reviews Drive Decisions | 93% of consumers read reviews before booking. A 4.7-star business consistently outperforms a 3.9 — regardless of actual quality. |
| Lapsed Customers Are Gold | Every business has hundreds of customers who visited once and disappeared. Reactivating them costs a fraction of acquiring new ones. |

---

## Contact Page

**Tag:** Book a Demo
**Headline:** 30 minutes. No commitment. *Live demo.*
**Subtext:** Pick a slot below. We'll show you exactly what AI looks like running in your business.

**What happens on the demo:**
- Live AI call agent demo in your industry
- Walkthrough of website + AI chat widget
- See the reactivation and review system live
- Get a recommendation for your specific business
- Every question answered — no scripts, no pressure

**Contact info:**
- 📧 main@arioun.com
- 📞 (928) 208-8239
- 🌐 arioun.com
