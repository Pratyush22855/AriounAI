# Layout
## Arioun Website — Skill 04

---

## Page Routing (single index.html)

```javascript
// main.js — page routing
var PAGES = ['home','services','how','about','contact'];

function showPage(name) {
  if (PAGES.indexOf(name) === -1) return; // whitelist validation
  PAGES.forEach(function(p) {
    var el = document.getElementById('page-' + p);
    if (el) {
      el.classList.remove('active');
      el.setAttribute('aria-hidden', 'true');
    }
  });
  var target = document.getElementById('page-' + name);
  if (target) {
    target.classList.add('active');
    target.removeAttribute('aria-hidden');
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
```

```css
.page { display: none; }
.page.active { display: block; }
```

---

## Grids

### 3-Column Service Grid (with separator lines)
```css
.grid-3-service {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1px;
  background: var(--accent-border);
  border: 1px solid var(--accent-border);
  border-radius: var(--radius-lg);
  overflow: hidden;
  margin-top: 3rem;
}
.grid-3-service > * {
  background: var(--bg-secondary);
}
```

### 3-Column Standard Grid
```css
.grid-3 {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
}
```

### 2-Column Standard Grid
```css
.grid-2 {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1.5rem;
}
```

### 2-Column Feature Row (alternating image + text)
```css
.feature-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: center;
  padding: 5rem 0;
  border-bottom: 1px solid var(--accent-border);
}
.feature-row:last-child { border-bottom: none; }
.feature-row.reverse .feature-visual { order: -1; }
```

### 2-Column Process Grid
```css
.process-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  border: 1px solid var(--accent-border);
  border-radius: var(--radius-lg);
  overflow: hidden;
  margin-top: 3rem;
}
/* Border rules for inner cells */
.process-step:nth-child(even) { border-right: none; }
.process-step:nth-last-child(-n+2) { border-bottom: none; }
/* Last step spans full width */
.process-step.full-width {
  grid-column: span 2;
  border-right: none;
  border-bottom: none;
  background: rgba(0,217,126,0.04);
  border-top: 2px solid rgba(0,217,126,0.2);
}
```

### Auto-fit Grid (for why/benefits cards)
```css
.grid-auto {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 1.5rem;
}
```

---

## Section Anatomy

Every section must follow this exact structure:

```html
<section class="section" aria-labelledby="[unique-id]">
  <div class="container">

    <!-- 1. Section tag (always first) -->
    <span class="section-tag">Category Label</span>

    <!-- 2. Headline -->
    <h2 class="t-h2" id="[unique-id]">Section Headline</h2>

    <!-- 3. Optional subtext -->
    <p class="t-body-lg" style="color:var(--text-secondary);max-width:560px;margin-bottom:3rem">
      Supporting description text.
    </p>

    <!-- 4. Content -->
    <!-- grid, cards, rows, etc. -->

  </div>
</section>
```

---

## Section Background Alternation

```
Section 1  →  bg-primary   (#0A0C0F)
Section 2  →  bg-secondary (#111419)  — add style="background:var(--bg-secondary)"
Section 3  →  bg-primary
Section 4  →  bg-secondary
Section 5  →  bg-primary
Final      →  .cta-band    (emerald green)
```

Use the `.rule` divider between same-background sections only.

---

## Responsive Breakpoints

```css
/* ── Desktop (default) ────────────── */
/* All grids are multi-column */

/* ── Below 1200px ─────────────────── */
@media (max-width: 1200px) {
  .hero-orb { width: 500px; height: 500px; }
}

/* ── Below 960px (tablet) ─────────── */
@media (max-width: 960px) {
  /* Collapse all multi-col grids */
  .grid-3, .grid-3-service,
  .grid-2, .feature-row,
  .process-grid { grid-template-columns: 1fr; }

  /* Feature row reverse loses reverse on mobile */
  .feature-row.reverse .feature-visual { order: 0; }

  /* Process grid — full-width step becomes normal */
  .process-step.full-width { grid-column: 1; }
  .process-step:nth-child(even) { border-right: 1px solid var(--accent-border); }

  /* Nav */
  .nav-links { display: none; }
  .hamburger { display: flex; }
}

/* ── Below 640px (mobile) ─────────── */
@media (max-width: 640px) {
  .hero .t-hero { font-size: 2.8rem; }
  .hero-orb { display: none; }
  .hero-stats { gap: 2rem; }
  footer { flex-direction: column; text-align: center; }
  .footer-nav { justify-content: center; }
}
```

---

## HTML Page Template

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <meta http-equiv="X-Content-Type-Options" content="nosniff"/>
  <meta http-equiv="Referrer-Policy" content="strict-origin-when-cross-origin"/>
  <title>Arioun — AI Infrastructure for Local Business</title>
  <meta name="description" content="Arioun builds and manages complete AI infrastructure for local businesses. Done for you. Live in 20 days."/>
  <link rel="canonical" href="https://arioun.com/"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
  <!-- Fonts, Calendly CSS, site CSS -->
  <link href="..." rel="stylesheet"/>
</head>
<body>
  <a href="#main" class="skip-link">Skip to content</a>
  <nav id="navbar" role="navigation" aria-label="Main navigation">...</nav>
  <nav id="mobile-nav" class="mobile-nav" aria-hidden="true">...</nav>
  <main id="main">
    <div id="page-home"    class="page active">...</div>
    <div id="page-services" class="page" aria-hidden="true">...</div>
    <div id="page-how"    class="page" aria-hidden="true">...</div>
    <div id="page-about"  class="page" aria-hidden="true">...</div>
    <div id="page-contact" class="page" aria-hidden="true">...</div>
  </main>
  <footer role="contentinfo">...</footer>
  <!-- Voiceflow, Calendly, site JS -->
</body>
</html>
```

---

## Skip Link (accessibility)

```css
.skip-link {
  position: absolute;
  top: -50px; left: 0;
  background: var(--accent);
  color: #000;
  padding: 0.5rem 1rem;
  font-weight: 700;
  z-index: 9999;
  border-radius: 0 0 8px 0;
  transition: top 0.2s;
  text-decoration: none;
}
.skip-link:focus { top: 0; }
```
