# Design System
## Arioun Website — Skill 01

---

## Brand

- **Personality:** Premium. Confident. Precise. Editorial.
- **Feel:** High-end consulting firm meets modern tech startup
- **NOT:** Generic SaaS. Purple gradients. Pill buttons everywhere. Startup clichés.
- **References:** Linear, Vercel, Stripe — but darker, bolder, more editorial

---

## Color Palette

```css
:root {
  /* ── Backgrounds ─────────────────── */
  --bg-primary:    #0A0C0F;   /* Page background */
  --bg-secondary:  #111419;   /* Cards, alt sections */
  --bg-tertiary:   #181D24;   /* Elevated / hover */
  --bg-surface:    #1E242E;   /* Inputs, surfaces */

  /* ── Accent — Electric Emerald ───── */
  --accent:        #00D97E;
  --accent-bright: #00FF93;   /* Hover */
  --accent-dim:    #00A85F;   /* Subtle */
  --accent-glow:   rgba(0, 217, 126, 0.15);
  --accent-border: rgba(0, 217, 126, 0.15);

  /* ── Text ────────────────────────── */
  --text-primary:   #EEF0F3;
  --text-secondary: #B4BAC4;
  --text-muted:     #7A8494;
  --text-disabled:  #3D4452;

  /* ── Utility ─────────────────────── */
  --white:   #FFFFFF;
  --black:   #000000;
  --success: #00D97E;
  --error:   #EF4444;
}
```

### Color Usage Rules
- `--bg-primary` → page background always
- `--bg-secondary` → cards, every other section
- `--accent` → CTAs, active states, icons, key highlights — never body text
- Never use pure white (#FFF) as a background
- Never introduce a 4th color — this palette only

---

## Typography

### Import (always these two, nothing else)
```css
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=Outfit:wght@300;400;500;600;700&display=swap');

:root {
  --font-display: 'Playfair Display', Georgia, serif;
  --font-body:    'Outfit', system-ui, sans-serif;
}
```

### Type Scale

| Token | Font | Size (clamp) | Weight | Line-height | Letter-spacing |
|---|---|---|---|---|---|
| `.t-hero` | Playfair | clamp(3.5rem, 8vw, 7rem) | 900 | 0.95 | -0.02em |
| `.t-h1` | Playfair | clamp(2.8rem, 5vw, 5rem) | 900 | 1.00 | -0.02em |
| `.t-h2` | Playfair | clamp(2rem, 3.5vw, 3.5rem) | 700 | 1.05 | -0.015em |
| `.t-h3` | Playfair | clamp(1.3rem, 2vw, 1.75rem) | 700 | 1.20 | 0 |
| `.t-label` | Outfit | 0.72rem | 700 | — | 0.16em |
| `.t-body-lg` | Outfit | 1.15rem | 300 | 1.75 | 0 |
| `.t-body` | Outfit | 1rem | 400 | 1.70 | 0 |
| `.t-body-sm` | Outfit | 0.875rem | 400 | 1.65 | 0 |
| `.t-caption` | Outfit | 0.75rem | 500 | — | 0 |

### Typography Rules
- Headlines = **Playfair Display** always
- Body = **Outfit** always
- Italic Playfair = only 1–2 accent words in hero (`<em>`)
- Labels/tags = Outfit, uppercase, `letter-spacing: 0.16em`
- **Never center-align body text** — only headlines and CTAs

---

## Spacing Scale

```css
:root {
  --s1:  4px;    --s2:  8px;    --s3:  12px;
  --s4:  16px;   --s5:  24px;   --s6:  32px;
  --s7:  48px;   --s8:  64px;   --s9:  96px;
  --s10: 128px;  --s11: 160px;  --s12: 200px;
}
```

### Section Padding
```css
.section          { padding: var(--s11) 5%; }           /* Desktop  */
@media (max-width: 960px)  { .section { padding: var(--s9)  5%; } }
@media (max-width: 640px)  { .section { padding: var(--s8)  5%; } }
```

### Containers
```css
.container       { max-width: 1200px; margin: 0 auto; }
.container-wide  { max-width: 1400px; margin: 0 auto; }
```

---

## Border Radius Scale

```css
--radius-sm:  4px;    /* Buttons, chips */
--radius-md:  8px;    /* Small cards */
--radius-lg:  12px;   /* Main cards */
--radius-xl:  16px;   /* Large surfaces */
```

- Never exceed 16px on large elements — keep it sharp and architectural
- Pill radius (100px) = mobile nav menu items only

---

## Shadow Scale

```css
--shadow-sm:  0 4px 16px rgba(0,0,0,0.3);
--shadow-md:  0 12px 40px rgba(0,0,0,0.4);
--shadow-lg:  0 20px 60px rgba(0,0,0,0.5);
--shadow-glow: 0 0 40px rgba(0,217,126,0.08);
--shadow-btn:  0 0 28px rgba(0,217,126,0.25);
--shadow-btn-hover: 0 0 44px rgba(0,217,126,0.4);
```
