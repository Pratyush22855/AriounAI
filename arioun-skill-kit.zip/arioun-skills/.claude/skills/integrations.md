# Integrations
## Arioun Website — Skill 06

All third-party scripts, security headers, and deployment config.

---

## Voiceflow — AI Chat Agent (Peter)

Place this script **before `</body>`** on every page.

```html
<!-- Voiceflow Chat Widget — Peter (Arioun AI Agent) -->
<script type="text/javascript">
  (function(d, t) {
    var v = d.createElement(t), s = d.getElementsByTagName(t)[0];
    v.onload = function() {
      window.voiceflow.chat.load({
        verify: { projectID: '69c2517a42b292115919d704' },
        url: 'https://general-runtime.voiceflow.com',
        versionID: 'production',
        voice: { url: 'https://runtime-api.voiceflow.com' }
      });
    }
    v.src = 'https://cdn.voiceflow.com/widget-next/bundle.mjs';
    v.type = 'text/javascript';
    s.parentNode.insertBefore(v, s);
  })(document, 'script');
</script>
```

---

## Calendly — Demo Booking

### In `<head>`:
```html
<link href="https://assets.calendly.com/assets/external/widget.css" rel="stylesheet"/>
```

### Before `</body>`:
```html
<script src="https://assets.calendly.com/assets/external/widget.js" type="text/javascript"></script>
```

### JS initialisation (in integrations.js):
```javascript
(function() {
  'use strict';
  var CAL_URL = 'https://calendly.com/main-arioun/45min';

  // Popup trigger — attach to all .btn-primary and demo CTAs
  window.openDemo = function(e) {
    if (e) { e.preventDefault(); e.stopPropagation(); }
    if (typeof Calendly !== 'undefined') {
      Calendly.initPopupWidget({ url: CAL_URL });
    }
    return false;
  };

  // Init inline widget (contact page)
  window.addEventListener('load', function() {
    if (typeof Calendly !== 'undefined') {
      Calendly.initInlineWidgets();
    }
  });
})();
```

### Inline embed (contact page only):
```html
<div class="calendly-inline-widget"
  data-url="https://calendly.com/main-arioun/45min?hide_gdpr_banner=1&background_color=111419&text_color=eef0f3&primary_color=00d97e"
  style="min-width:280px;height:660px"
  aria-label="Book a demo call">
</div>
```

---

## Button onclick for demo CTAs

All demo CTA buttons use:
```html
<a href="#" class="btn btn-primary" onclick="return openDemo(event)">Book a Demo →</a>
```

Never hardcode the Calendly URL in buttons — always use the `openDemo()` function.

---

## Security — Netlify `_headers` File

Create `_headers` in project root:

```
/*
  Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()
  Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://assets.calendly.com https://cdn.voiceflow.com https://fonts.googleapis.com; style-src 'self' 'unsafe-inline' https://assets.calendly.com https://fonts.googleapis.com https://fonts.gstatic.com; font-src 'self' https://fonts.gstatic.com; frame-src https://calendly.com https://*.voiceflow.com; img-src 'self' data: https:; connect-src 'self' https://calendly.com https://*.voiceflow.com https://general-runtime.voiceflow.com https://runtime-api.voiceflow.com; object-src 'none'; base-uri 'self'; upgrade-insecure-requests;
  Cache-Control: public, max-age=3600
```

---

## Security — Apache `.htaccess`

```apache
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
RewriteCond %{HTTP_HOST} ^www\.arioun\.com [NC]
RewriteRule ^(.*)$ https://arioun.com/$1 [L,R=301]

<IfModule mod_headers.c>
  Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
  Header always set X-Content-Type-Options "nosniff"
  Header always set X-Frame-Options "DENY"
  Header always set Referrer-Policy "strict-origin-when-cross-origin"
  Header always set Permissions-Policy "camera=(), microphone=(), geolocation=(), payment=()"
  Header unset X-Powered-By
  Header unset Server
</IfModule>

Options -Indexes

<FilesMatch "\.(env|log|sql|bak|sh|yml|yaml|lock)$">
  Order allow,deny
  Deny from all
</FilesMatch>

<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css application/javascript
</IfModule>

ErrorDocument 404 /index.html
```

---

## Google Fonts (always in `<head>`)

```html
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
```

---

## JS — Navbar Scroll & Page Routing (main.js)

```javascript
(function() {
  'use strict';

  var PAGES = ['home','services','how','about','contact'];

  // Page routing — whitelist validated
  window.showPage = function(name) {
    if (PAGES.indexOf(name) === -1) return;
    PAGES.forEach(function(p) {
      var el = document.getElementById('page-' + p);
      if (el) { el.classList.remove('active'); el.setAttribute('aria-hidden','true'); }
    });
    var t = document.getElementById('page-' + name);
    if (t) { t.classList.add('active'); t.removeAttribute('aria-hidden'); }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Mobile nav
  window.toggleMob = function(btn) {
    var nav = document.getElementById('mobile-nav');
    var open = nav.classList.toggle('open');
    nav.setAttribute('aria-hidden', open ? 'false' : 'true');
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    document.body.style.overflow = open ? 'hidden' : '';
  };
  window.closeMob = function() {
    var nav = document.getElementById('mobile-nav');
    var btn = document.querySelector('.hamburger');
    nav.classList.remove('open');
    nav.setAttribute('aria-hidden', 'true');
    if (btn) btn.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  };

  // Navbar shadow on scroll
  var navEl = document.getElementById('navbar');
  var tick = false;
  window.addEventListener('scroll', function() {
    if (!tick) {
      requestAnimationFrame(function() {
        if (navEl) navEl.classList.toggle('scrolled', window.scrollY > 20);
        tick = false;
      });
      tick = true;
    }
  }, { passive: true });

  // Close mobile nav on resize
  window.addEventListener('resize', function() {
    if (window.innerWidth > 960) closeMob();
  }, { passive: true });

  // Close mobile nav on Escape
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeMob();
  });

  // Dynamic copyright year
  var yr = document.getElementById('copyright-year');
  if (yr) yr.textContent = new Date().getFullYear();

  // Initial aria-hidden on inactive pages
  PAGES.forEach(function(p) {
    var el = document.getElementById('page-' + p);
    if (el && !el.classList.contains('active')) el.setAttribute('aria-hidden', 'true');
  });

})();
```

---

## Deployment — Quick Reference

| Platform | Files needed | Steps |
|---|---|---|
| **Netlify** | `_headers` | Drag & drop folder → add domain |
| **Cloudflare Pages** | `_headers` | Upload → add domain |
| **Apache / cPanel** | `.htaccess` | Upload to `public_html/` |
| **Nginx VPS** | `nginx.conf` | Point root to folder, reload nginx |

**Fastest deploy:** Netlify — drag the project folder to app.netlify.com. Free SSL + CDN automatic.
