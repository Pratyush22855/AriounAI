# Arioun Website — Claude Code Instructions

## Read This First

Before writing any code, read ALL skill documents in `.claude/skills/` in this order:

1. `.claude/skills/design-system.md` — Colors, fonts, spacing, CSS variables
2. `.claude/skills/components.md` — Every reusable component with full CSS
3. `.claude/skills/animations.md` — All keyframes and scroll reveal JS
4. `.claude/skills/layout.md` — Page structure, grids, section anatomy
5. `.claude/skills/content.md` — All company copy, stats, and data
6. `.claude/skills/integrations.md` — Voiceflow, Calendly, security headers

---

## Project

**Company:** Arioun — AI Infrastructure for Local Business
**Stack:** HTML + CSS + Vanilla JS (single index.html entry, separate CSS/JS files)
**Pages:** Home · Services · How It Works · About · Contact
**Deploy:** Netlify

## Output File Structure

```
arioun-website/
├── index.html
├── styles/
│   ├── base.css        ← Reset, variables, typography
│   ├── components.css  ← All component styles
│   ├── layout.css      ← Grids, sections, spacing
│   └── animations.css  ← Keyframes and transitions
├── scripts/
│   ├── main.js         ← Page routing, navbar, general
│   ├── animations.js   ← Scroll reveal, counters
│   └── integrations.js ← Calendly + Voiceflow init
├── _headers            ← Netlify security headers
├── .htaccess           ← Apache fallback
└── README.md           ← Deploy instructions
```

## Hard Rules

1. Read ALL skill files before writing any code
2. No inline styles — CSS classes only
3. All JS in strict mode, wrapped in IIFE
4. Every H2 must have a `.section-tag` eyebrow above it
5. Every page must end with the emerald `.cta-band`
6. Fully responsive at 960px and 640px
7. Include Voiceflow + Calendly on every page
8. Never use fonts other than Playfair Display + Outfit
9. Never use colors outside the defined palette
10. Output production-ready, hostable files
